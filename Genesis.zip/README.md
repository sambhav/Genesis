# Genesis
### The Almighty Book Downloader

#### A Chrome Extension to download your favorite books as pdfs/ebooks. Uses Lib-Gen as a repository.
